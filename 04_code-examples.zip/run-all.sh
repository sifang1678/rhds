#!/bin/bash

source config.env

ls $alspacdir/current

