################################################################################
packages <- c("tidyverse", "ewaff", "R.utils")
lapply(packages, require, character.only=T)

dir <- "/project/alcohol-use/working"
dir.data <- "/project/alcohol-use/working/data"
dir.figs <- "/project/alcohol-use/working/figs"
dir.logs <- "/project/alcohol-use/working/logs"

dir.meth <- "~/rdsf/release-v4/data"








